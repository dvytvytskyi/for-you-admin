-- Add reference to amo_crm_user in users table
ALTER TABLE "users" ADD COLUMN "amo_crm_user_id" uuid UNIQUE;

-- Add foreign key constraint
ALTER TABLE "users" 
ADD CONSTRAINT "fk_users_amo_crm_user" 
FOREIGN KEY ("amo_crm_user_id") 
REFERENCES "amo_crm_users"("id") 
ON DELETE SET NULL;

-- Create index for faster lookups
CREATE INDEX "idx_users_amo_crm_user_id" ON "users"("amo_crm_user_id");
